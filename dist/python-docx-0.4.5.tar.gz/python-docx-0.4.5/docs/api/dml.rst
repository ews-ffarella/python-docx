
.. _dml_api:

DrawingML objects
=================

Low-level drawing elements like color that appear in various document
contexts.


|ColorFormat| objects
---------------------

.. autoclass:: docx.dml.color.ColorFormat()
   :members:
   :undoc-members:
